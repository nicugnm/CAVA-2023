Double Double Domino - GHERGU NICOLAE-MARIUS 462, CTI, CAVA - 2023

1. the libraries required to run the project including the full version of each library

Example:
python --> 3.9

numpy==1.26.1
opencv_python==4.8.1.78

2. how to run each task and where to look for the output file.

Example:

Task 1: 
script: solutie.py
modify script: run solutie.py AFTER you modify the folder in which is the test data (you can find in script the name of the variable that you need to modify -> for now, is 'antrenare/' (don't forgot the "/")
output: the output folder is rezultate/ which contains the answers for every game and move.